#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define ITOA_DECIMAL 10

// pra facilitar o tamanho max de chars de um registro no arquivo eh fixo
#define TAM_BUFF_ARQ_SEQ 24
#define TAM_BUFF_ARQ_INDICE 10
#define NOME_ARQ_SEQ "arquivo-sequencial.txt"
#define NOME_ARQ_INDICE "arquivo-sequencial-indice.txt"

typedef struct arq_seq_reg {
  char nome[10];
  int idade;
  int salario;
  int numero;
} ARQ_SEQ_REG;

typedef struct arq_indice_reg {
  int chave;
  int end_fisico;
  int exclusao;
} ARQ_INDICE_REG;

int ler_chave_indice(FILE* arqIndice) {
  // aqui lemos o tamanho intero para evitar de bagunçar a posicao de leitura do arquivo
  char buff[TAM_BUFF_ARQ_INDICE + 1]; // TODO talvez isso não seja mais necessário, pode-se ler somente 5 chars
  int i;
  if (fgets(buff, sizeof(buff), arqIndice) == NULL) {
    return -1;
  }
  buff[4] = '\0';
  return atoi(buff);
}

void bublesort_arquivo_indice(FILE* arq) {
  printf("..: ORDENANDO ARQUIVO DE INDICE ::..\n");

  char buffAtual[TAM_BUFF_ARQ_INDICE + 1];
  char buffProx[TAM_BUFF_ARQ_INDICE + 1];
  int chave, proxChave;
  // https://stackoverflow.com/questions/10669673/saving-off-the-current-read-position-so-i-can-seek-to-it-later
  int posInicial, arqTam, qtdRegistros, i;

  fseek(arq, 0, SEEK_END);
  arqTam = ftell(arq);
  rewind(arq);
  qtdRegistros = (arqTam / TAM_BUFF_ARQ_INDICE - 1);

  int sort = 0;
  do {
    sort = 0;
    for (i=0; i < qtdRegistros - 1; i++) {
      fseek(arq, (TAM_BUFF_ARQ_INDICE + 1) * i, SEEK_SET);

      posInicial = ftell(arq);
      chave = ler_chave_indice(arq); // lendo a chave
      fseek(arq, posInicial, SEEK_SET); // voltando pra posicao anterior para ler a linha inteira [1]
      fgets(buffAtual, sizeof(buffAtual), arq); // lendo linha. 
      // [1]: Sim, seria melhor somente ler a linha e dps extrair a chave dessa string. Fazer isso dps

      proxChave = ler_chave_indice(arq);
      fseek(arq, (posInicial + TAM_BUFF_ARQ_INDICE + 1), SEEK_SET);
      fgets(buffProx, sizeof(buffAtual), arq);

      if (proxChave < chave) {
        fseek(arq, posInicial, SEEK_SET);
        fputs(buffProx, arq);

        fseek(arq, (posInicial + TAM_BUFF_ARQ_INDICE + 1), SEEK_SET);
        fputs(buffAtual, arq);

        sort = 1;
      }
    }
  } while (sort);
}

void busca_arquivo_sequencial(int chaveBusca) {
  printf("..: BUSCA SEQUENCIAL PELA CHAVE: %d ::..\n", chaveBusca);

  FILE* arq;
  arq = fopen(NOME_ARQ_SEQ, "rt");
  
  if (arq == NULL) {
  	printf("Erro ao abrir arquivo %s\n", NOME_ARQ_SEQ);
  	return;
  }
  
  fseek(arq, 0, SEEK_SET);

  char buff[TAM_BUFF_ARQ_SEQ];
  char aux[10];
  int i, j, registro_encontrado = 0;

  ARQ_SEQ_REG* registro = (ARQ_SEQ_REG*)malloc(sizeof(ARQ_SEQ_REG));
  
  while(!registro_encontrado && fgets(buff, sizeof(buff), arq) !=  NULL) {
    for (i=0; buff[i]!=','; i++) {
      aux[i] = buff[i];
    }
    aux[i++] = '\0';
    registro->numero = atoi(aux);

    if (registro->numero != chaveBusca) {
      continue;
    } else {
    	registro_encontrado = 1;
	  }

    for (j=0; buff[i]!=','; i++, j++) {
      registro->nome[j] = buff[i];
    }
    i++;
    registro->nome[j] = '\0';

    for(j=0; buff[i]!=','; i++, j++) {
      aux[j] = buff[i];
    }
    i++;
    aux[j] = '\0';
    registro->idade = atoi(aux);

    for(j=0; i<TAM_BUFF_ARQ_SEQ; i++, j++) {
      aux[j] = buff[i];
    }
    aux[j] = '\0';
    registro->salario = atoi(aux);

    printf("Registro encontrado por busca sequencial\n");
    printf("\tNUMERO: %d\n", registro->numero);
    printf("\tNOME: %s\n", registro->nome);
    printf("\tIDADE: %d\n", registro->idade);
    printf("\tSALARIO: %d\n", registro->salario);

    fclose(arq);
  }
}

void gerar_arquivo_indice_ordenado() {
  printf("..:: GERANDO ARQUIVO DE INDICE ::..\n");

  FILE* arqDados = fopen(NOME_ARQ_SEQ, "rt");
  FILE* arqIndice = fopen(NOME_ARQ_INDICE, "w+t");
  
  if (arqDados == NULL) {
  	printf("Erro ao abrir arquivo %s\n", NOME_ARQ_SEQ);
  	return;
  }
  if (arqIndice == NULL) {
  	printf("Erro ao abrir arquivo %s\n", NOME_ARQ_INDICE);
  	return;
  }

  char buff[TAM_BUFF_ARQ_SEQ + 1];
  char buffIndice[TAM_BUFF_ARQ_INDICE + 1];
  char endFisicoStr[10];
  int i, j, chave, endFisico = 1;

  while (fgets(buff, sizeof(buff), arqDados) !=  NULL) {
    for (i=0; buff[i]!=','; i++) {
      buffIndice[i] = buff[i]; // escrevendo chave no buffer q vai ser escrito
    }

    if (buffIndice[0] < '0' || buffIndice[0] > '9') { // por algum motivo as vezes está sendo lido um valor vazio
      continue;
    }

    buffIndice[i] = ',';

    // endereco fisico nesse caso sera a linha do registro no arquivo de dados
    itoa(endFisico, endFisicoStr, ITOA_DECIMAL);
    int endFisicoStrLength = strlen(endFisicoStr);
    if (endFisicoStrLength < 2) { // ajustando endFisicoStr para 2 digitos
      endFisicoStr[1] = endFisicoStr[0];
      endFisicoStr[0] = '0';
      endFisicoStr[endFisicoStrLength+1] = '\0';
    }

    endFisico += 1;

    for (i+=1, j=0; endFisicoStr[j]!='\0'; i++, j++) {
      buffIndice[i] = endFisicoStr[j]; // escrevendo end. fisico no buffer q vai ser escrito
    }
    buffIndice[i++] = ',';

    buffIndice[i++] = '0'; // escrevendo 0 para o valor de 'Exclusao'
    buffIndice[i++] = '\n';
    buffIndice[i] = '\0';
    fputs(buffIndice, arqIndice);
  }
  printf("..:: ARQUIVO DE INDICE GERADO: %s ::..\n", NOME_ARQ_INDICE);

  bublesort_arquivo_indice(arqIndice);

  fclose(arqIndice);
  fclose(arqDados);
}

void busca_arquivo_indice(int chaveBusca) {
  printf("..: BUSCA ATRAVES DO INDICE PELA CHAVE: %d ::..\n", chaveBusca);

  int arqTam;
  FILE* arqIndice = NULL;
  
  arqIndice = fopen(NOME_ARQ_INDICE, "rt");

  if (arqIndice == NULL) {
  	printf("Erro ao abrir arquivo %s\n", NOME_ARQ_INDICE);
  	return;
  }

  fseek(arqIndice, 0, SEEK_END);
  arqTam = ftell(arqIndice);
  rewind(arqIndice);

  ler_chave_indice(arqIndice);

  int inf = 0, meio;
  int sup = (arqTam / TAM_BUFF_ARQ_INDICE - 1);
  int chave = -1;

  // TODO fazer uma binary search pra encontrar a chave
  // dps usar o endFisico para calcular a posicao desse registro no arquivo de dados
  
  // while(chave != -1 || inf <= sup) { 
  //   meio = (inf + sup) / 2;
    


  // }


  fclose(arqIndice);
}

int main() {
	busca_arquivo_sequencial(1950);
	gerar_arquivo_indice_ordenado();
  busca_arquivo_indice(1050);
  return 0;
}

